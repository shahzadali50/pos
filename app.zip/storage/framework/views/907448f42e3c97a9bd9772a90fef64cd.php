
<?php $__env->startSection('content'); ?>
<h1>Add category</h1>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BS.IT Material\my practice work\laravel\pos\resources\views/add-categories.blade.php ENDPATH**/ ?>