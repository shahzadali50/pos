<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-12">
        <h2 class="page-title">Brand Update</h2>
        <div class="card shadow mb-4">

            <div class="card-body">
                <form action="<?php echo e(route('brand.update',$Brand->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Add Brand</label>
                                <input type="text" value="<?php echo e($Brand->name); ?>" name="name" class="form-control" placeholder="Add Brand" required>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Status">Status</label>
                                <select name="status" class="form-control" id="Status">
                                    <option value="1" <?php echo e($Brand->status == 1 ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e($Brand->status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn mb-2 btn-info">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BS.IT Material\my practice work\laravel\pos\resources\views/brand-update.blade.php ENDPATH**/ ?>