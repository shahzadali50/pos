<!-- resources/views/products/edit.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8 col-12">
        <h2 class="page-title">Product Update</h2>
        <div class="card shadow mb-4">
            <div class="card-body">
                <form action="<?php echo e(route('product.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Product Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Product Name" value="<?php echo e($product->name); ?>" required>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Status">Category</label>
                                <select name="category_id" class="form-control" id="Status" required>
                                    <option disabled>Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="Status">Brand</label>
                                <select name="brand_id" class="form-control" id="Status" required>
                                    <option disabled>Select Brand</option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->id); ?>" <?php echo e($brand->id == $product->brand_id ? 'selected' : ''); ?>>
                                        <?php echo e($brand->name); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Code</label>
                                <input name="code" value="<?php echo e($product->code); ?>" type="number" class="form-control" placeholder="Code" required>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Quantity</label>
                                <input name="quantity" value="<?php echo e($product->quantity); ?>" type="number" class="form-control" placeholder="Quantity" required>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Purchase Rate</label>
                                <input name="purchase_rate" value="<?php echo e($product->purchase_rate); ?>" type="number" class="form-control" placeholder="Purchase Rate" required>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="simpleinput">Sale Rate</label>
                                <input name="sale_rate" value="<?php echo e($product->sale_rate); ?>" type="number" class="form-control" placeholder="Sales Rate" required>
                            </div>

                        </div>


                        <!-- Add other form fields as needed -->

                        <div class="col-md-6">
                            <label for="simpleinput">Drop files here, paste or browse</label>
                            <input name="photo" type="file" class="form-control mb-3" accept="image/*">
                            <?php if($product->photo): ?>
                            <p>Current Photo:</p>
                            <img src="<?php echo e(asset('storage/' . $product->photo)); ?>" alt="Product Photo" style="max-width: 100px; max-height: 100px;">
                            <?php else: ?>
                            <p>No photo available</p>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="exampleFormControlTextarea1">Description</label>
                                <textarea name="description" value="<?php echo e($product->description); ?>" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo e($product->description); ?></textarea>
                            </div>
                        </div>

                        <div class="col-12">

                            <button type="submit" class="btn mb-2 btn-info">Update Product</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\BS.IT Material\my practice work\laravel\pos\resources\views/product-update.blade.php ENDPATH**/ ?>