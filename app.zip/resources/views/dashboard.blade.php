@extends('layouts/app')


@section('content')
  <h1>Welcome to POS</h1>
@endsection