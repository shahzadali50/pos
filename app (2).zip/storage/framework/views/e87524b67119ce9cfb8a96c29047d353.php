
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Head::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>

  </head>
  <body class="light ">

    <div class="container vh-100">
      <div class="row align-items-center h-100">
        <div  class="col-lg-4 col-md-5 col-10 mx-auto text-center bg-white  shadow  rounded">

        <form action="<?php echo e(route('loginuser')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <a class="navbar-brand mx-auto mt-2 flex-fill text-center" href="index.php">
            <img src="<?php echo e(asset('assets/img/logo/pos_logo.jpg')); ?>" style="width: 100px;height: 100px;">
          </a>
          <h1 class="h4 mb-3">POS</h1>
          <h1 class="h6 mb-3">Sign in</h1>

          <div class="form-group">
            <label for="inputEmail" class="sr-only">Email address</label>
            <input type="text" id="inputEmail" name="email" class="form-control form-control-lg" placeholder="Email address" required="" autofocus="">
          </div>
          <div class="form-group">
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" id="inputPassword" name="password" class="form-control form-control-lg" placeholder="Password" required="">
          </div>
          <div class="checkbox mb-3">
            <label>
              <input type="checkbox" value="remember-me"> Stay logged in </label>
          </div>
          <button class="btn btn-lg btn-admin btn-block" type="submit">Log In</button>
          <p class="mt-5 mb-3 text-muted">©2023</p>
        </form>
        </div>
      </div>
    </div>
   <?php if (isset($component)) { $__componentOriginal31cb59423ba1f759026ebe11d6ad323d = $component; } ?>
<?php $component = App\View\Components\Foot::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('foot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Foot::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d)): ?>
<?php $component = $__componentOriginal31cb59423ba1f759026ebe11d6ad323d; ?>
<?php unset($__componentOriginal31cb59423ba1f759026ebe11d6ad323d); ?>
<?php endif; ?>

  </body>
</html>
</body>
</html>
<?php /**PATH D:\BS.IT Material\my practice work\laravel\pos\resources\views/login.blade.php ENDPATH**/ ?>