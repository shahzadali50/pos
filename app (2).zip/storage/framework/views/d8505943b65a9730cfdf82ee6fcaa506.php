<?php if (isset($component)) { $__componentOriginal781d22988f835a9692410092c1d21cd6 = $component; } ?>
<?php $component = App\View\Components\Head::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Head::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781d22988f835a9692410092c1d21cd6)): ?>
<?php $component = $__componentOriginal781d22988f835a9692410092c1d21cd6; ?>
<?php unset($__componentOriginal781d22988f835a9692410092c1d21cd6); ?>
<?php endif; ?>
<body>
    <div class="continer">
        <div class="row justify-content-center align-items-center h-100">
            <div class="col-5">
                <div class="card">
                    <div class="card-header ">
                        <div class="text-center">
                            <img src="<?php echo e(asset('assets/img/logo/pos_logo.jpg')); ?>" style="width: 70px;height: 70px;">
                        </div>
                        <h4 class="text-center">POS</h4>
                        <p class="text-center">MEN-WOMEN-KIDS-HOME</p>
                        <h6>
                            Contact Information
                        </h6>
                        <p class="m-0">Address : TBZ Street No # 01 Sahiwal</p>
                        <p class="m-0">Email :ZELLBURY@gmail.com</p>
                        <p class="m-0">Phone :+92 23456789234 </p>


                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Product</th>
                                    <th scope="col">QTY</th>
                                    <th scope="col">Price</th>
                                </tr>
                            </thead>
                            <tbody>





                            </tbody>
                        </table>

                        <div class="d-flex justify-content-between">
                            <h6>Disc</h6>
                            <p>3%</p>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6>Grand Total</h6>
                            <p>1200</p>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>

</body>
</html>
<?php /**PATH D:\BS.IT Material\my practice work\laravel\pos\resources\views/pos-receipt.blade.php ENDPATH**/ ?>