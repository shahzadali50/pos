<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="img/logo/pos_logo.jpg">
        <link rel="icon" href="img/logo/pos_logo.jpg" type="image/gif" sizes="16x16">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
        <!-- Simple bar CSS -->
        <link rel="stylesheet" href="<?php echo e(url('assets/css/simplebar.css')); ?>">
        <!-- Fonts CSS -->

        <link rel="stylesheet" href="<?php echo e(url('assets/css/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/select2.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/dropzone.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/uppy.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/jquery.steps.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/jquery.timepicker.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/quill.snow.css')); ?>">
        <!-- Date Range Picker CSS -->
        <link rel="stylesheet" href="<?php echo e(url('assets/css/daterangepicker.css')); ?>">
        <!-- App CSS -->
        <link rel="stylesheet" href="<?php echo e(url('assets/css/app-light.css')); ?>" id="lightTheme">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/app-dark.css')); ?>" id="darkTheme" disabled>
        <script src="<?php echo e(url('js/sweetalert2.min.js')); ?>"></script>
        <script src="<?php echo e(url('js/all.min.js')); ?>"></script>
        <link rel="stylesheet" href="<?php echo e(url('assets/css/sweetalert2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/dataTables.bootstrap4.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">

        <title>POS</title>
        <style type="text/css">
                .btn-admin,
                .bg-admin,
                .alert-danger {
                        color: #ffffff !important;
                        background-color: #17A2B8;
                        border-color: #17A2B8;
                }

                .btn-admin:hover {
                        background-color: #066b7a;

                }

                .text-admin {
                        color: #17A2B8;
                }

                .btn-admin2,
                .bg-admin2 {
                        color: white;
                        background-color: black;
                        border-color: black;

                }

                .card-bg {

                        background-color: #17A2B8;

                }

                .card-text {
                        color: #ffffff;
                }
        </style>
</head>
<?php /**PATH E:\BS.IT Material\my practice work\laravel\pos\resources\views/components/head.blade.php ENDPATH**/ ?>